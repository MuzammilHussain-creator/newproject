#include "Player.h"
#include<iostream>
using namespace std;
#include<string>
Player::Player()
{
	size = 0;
}
Player::Player(string N, string H, string I, string C, string P)
{
	weapon = new Weapon*[2];
	name = N;
	health = H;
	id = I;
	costume = C;
	parachute = P;
}
void Player::Add_Player(Weapon *wepon)
{
	int i = 0;
	Weapon **temp = weapon;
	//weapon = new Weapon*[2];
	if (size < 2)
	{
		for (i = 0; i < size; i++)
		{
			weapon[i] = temp[i];
		}
		weapon[i] = wepon;
		size++;
	}
	else
	{
		cout << "You Already Have Two Weapons " << endl;
	}
}
void Player::Player_Display()
{
	cout << "Name: " << name << " " << endl;
	cout << "ID: " << id << endl;
	cout << "Health: " << health << endl;
	cout << "Costume: " << costume << endl;
	cout << "Parachute: " << parachute << endl;
	for (int i = 0; i < size; i++)
	{
		weapon[i][0].print();
	}
}
Player::~Player()
{
	//cout << "Desstrter Of Player: " << endl;
}
