#include "OneD.h"


OneD::OneD(string n, Point p1, Point p2) :Shapes(n), p1(p1), p2(p2)
{

}
void OneD::Print()
{
	cout << "In OneD: " << endl;
}

OneD::~OneD()
{
}
