#include "Match.h"
#include<iostream>
#include<string>
using namespace std;
#include"Lobby.h"
Match::Match()
{
	lobby = NULL;
	type = 0;
	int size = 0;
}
Match::Match(int a)
{
	if (a == 1)
	{
		this->type = a;
		lobby = new Lobby*[100];
	}
	else
	{
		if (a == 2)
		{
			this->type = a;
			lobby = new Lobby*[50];
		}
		else
		{
			if (a == 3)
			{
				lobby = new Lobby*[25];
				this->type = a;
			}
			else
				cout << "Type Does not Match: " << endl;

		}

	}
}
void Match::addlobby(Lobby *loby)
{
	int i = 0;
	Lobby **temp = this->lobby;
	if (type == 2)
	{
		if (size < 2)
		{
			for (i = 0; i < size; i++)
			{
				lobby[i] = temp[i];
			}
			lobby[i] = loby;
			size++;
		}
		else
		{
			cout << "Last  Lobby Can't Join Match " << endl;
		}
	}
	else
	{
		if (type == 1 || type == 3)
		{
			for (i = 0; i < size; i++)
			{
				lobby[i] = temp[i];
			}
			lobby[i] = loby;
			size++;
		}
		else
		{
			cout << "Type Does not Match: " << endl;
		}
	}
}
void Match::Display()
{
	for (int i = 0; i < size; i++)
	{
		lobby[i][0].Print();
	}
}
Match::~Match()
{
}
