#include<iostream>
#include"DayType.h"
using namespace std;
DayType::DayType()
{

}
void DayType::setDay(int a)
{
	day = a;
}
int DayType::RetDay()
{
	return day;
}
void DayType::Next_Day(int h)
{
	nextday = h;
}
int DayType::Next_Ret()
{
	return nextday;
}
void DayType::Prev_Day(int e)
{
	preday = e;
}
int DayType::Ret_Prev()
{
	return preday;
}
void DayType::printDay()
{
	int d = 0;
	d = day;
	if (d == 1)
		cout << "MonDay" << endl;
	if (d == 2)
		cout << "TuesDay" << endl;
	if (d == 3)
		cout << "WednesDay" << endl;
	if (d == 4)
		cout << "ThursDay" << endl;
	if (d == 5)
		cout << "FriDay" << endl;
	if (d == 6)
		cout << "SaturDay" << endl;
	if (d == 7)
		cout << "SunDay" << endl;
}
void DayType::prinNext()
{
	int d = 0;
	d = day+nextday;
	d = d % 10;
	if (d == 1)
		cout << "MonDay" << endl;
	if (d == 2)
		cout << "TuesDay" << endl;
	if (d == 3)
		cout << "WednesDay" << endl;
	if (d == 4)
		cout << "ThursDay" << endl;
	if (d == 5)
		cout << "FriDay" << endl;
	if (d == 6)
		cout << "SaturDay" << endl;
	if (d == 7)
		cout << "SunDay" << endl;
}
void DayType::prinPrev()
{
	int d = 0;
	int d1 = 0;
	d = day - preday-1;
	d1 = day - preday;
	if (d == -7 || d1 == 1)
		cout << "MonDay" << endl;
	if (d == -6 || d1 == 2)
		cout << "TuesDay" << endl;
	if (d == -5 || d1 == 3)
		cout << "WednesDay" << endl;
	if (d == -4 || d1 == 4)
		cout << "ThursDay" << endl;
	if (d == -3 || d1 == 5)
		cout << "FriDay" << endl;
	if (d == -2 || d1 == 6)
		cout << "SaturDay" << endl;
	if (d == -1 || d1 == 7)
		cout << "SunDay" << endl;
}
DayType::~DayType()
{
	
}