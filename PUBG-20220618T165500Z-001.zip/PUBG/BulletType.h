#pragma once
#include<iostream>
using namespace std;
#include<string>
class BulletType
{
	string bullettype;
	int bullets;
	int firerate;
	int range;
	int maxsize;
public:
	BulletType();
	BulletType(string, int, int, int, int);
	void SetBulletType(string);
	void SetBullets(int);
	void SetFirerate(int);
	void SetRange(int);
	void SetMaxSize(int);
	string getBultesType();
	int GetBullets();
	int GetFireRate();
	int GetRange();
	int GetMaxSize();
	void print();
	BulletType(BulletType &obj);
	~BulletType();
};

