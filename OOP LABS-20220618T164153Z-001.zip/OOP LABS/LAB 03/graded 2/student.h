#pragma once
class student
{
	char *name;
	int size1, size2, size3;
	char *Anumber;
	char *Atype;
	float money;
	int day;
	static int count;
	
public:
	int inc();
	student(char*, char*, char*, float,int);
	int days();
	char* NAMES();
};