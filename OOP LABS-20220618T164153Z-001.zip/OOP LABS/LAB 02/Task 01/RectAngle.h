#pragma once;
class RectAngle
{
private:
	int length = 1, widht = 1;
public:
	RectAngle();
	void setLength(float);
	int getLength();
	void CaluclateArea(float,float);
	void setWidth(float);
	int getWidth();
	void Parameter(float,float);
	~RectAngle();

};