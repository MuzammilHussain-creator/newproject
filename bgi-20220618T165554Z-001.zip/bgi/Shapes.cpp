#include "Shapes.h"
#include<iostream>
using namespace std;
Shapes::Shapes()
{
	name = '\0';
}
Shapes::Shapes(string name)
{
	this->name = name;
}
void Shapes::Print()
{
	cout << "Name: ";
	cout << name << endl;
}
Shapes::~Shapes()
{
}
