#include<iostream>
using namespace std;
int NoParaMatric();
int NoParaMatric(int a, int b);
int NoParaMatric(int a, int b, int c);
int NoParaMatric(char *arr,char *arr2);
int main()
{
	int num1 = 0, num2 = 0,num3=0,Sum=0;
	char *arr=new char[10];
	char *arr2=new char[10];
	NoParaMatric();
	cout << "Enter Number 1: ";
	cin >> num1;
	cout << "Enter Number 2: ";
	cin >> num2;
	cout << "Enter Number 3: ";
	cin >> num3;
	cout << "Enter First Array of 10 characters: ";
	for (int i = 0; i < 10; i++)
	{
		cin >> arr[i];
	}
	cout << "Enter Second Array of 10 characters: ";
	for (int i = 0; i < 10; i++)
	{
		cin >> arr2[i];
	}
	Sum=NoParaMatric(num1,num2);
	cout << "sum1: " << Sum << endl;
	Sum = NoParaMatric(num1, num2,num3);
	cout << "sum2: " << Sum << endl;
	NoParaMatric(arr,arr2);
	return 0;
}
int NoParaMatric()
{
	cout << "This is the Sum Of Function" << endl;
	return 0;
}
int NoParaMatric(int a, int b)
{
	int sum = 0;
	sum = a + b;
	return sum;
}
int NoParaMatric(int a, int b,int c)
{
	int sum = 0;
	sum = a + b+c;
	return sum;
}
int NoParaMatric(char *arr,char *arr2)
{
	int i = 0;
	char *arr3 = new char[21];
	for (i = 0; i < 10; i++)
	{
		arr3[i] = arr[i];
	}
	for (int j = 0; j < 10; j++)
	{
		if (j == 0)
		{
			arr3[i] = ' ';
			i++;
		}
		arr3[i] = arr[j];
		i++;
	}
	cout << endl;
	for (i = 0; i<20; i++)
	{
		cout << arr3[i];
	}
	return 0;
}