#include<iostream>
#include<fstream>
#include"student.h"
using namespace std;
student::student(char *name, char *Anumber, char *Atype, float mony, int day)
{
	ofstream fout;
	fout.open("out.open", ios::app);
	int size1 = 0, size2 = 0, size3 = 0;
	size1 = strlen(name);
	size2 = strlen(Anumber);
	size3 = strlen(Atype);
	this->money = mony;
	this->day = day;
	this->name = new char[size1 + 1];
	this->Anumber = new char[size2 + 1];
	this->Atype = new char[size3 + 1];
	for (int i = 0; i < size1; i++)
	{
		this->name[i] = name[i];
	}
	for (int i = 0; i < size2; i++)
	{
		this->Anumber[i] = Anumber[i];
	}
	for (int i = 0; i < size3; i++)
	{
		this->Atype[i] = Atype[i];
	}
	if (this->Atype[0] == 'C' || this->Atype[0] == 'c')
		days();
	fout << this->money;
}
int student::inc()
{
	count++;
	return count;
}
int student::days()
{
	day++;
	money = (money + (0.05*money));
	return money;
}
char* student::NAMES()
{
	ofstream fout;
	fout.open("output.txt", ios::app);
	for (int i = 0; i < size1; i++)
	{
		fout << this->name[i];
	}
	return 0;
}