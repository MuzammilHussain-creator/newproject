#include "PUBG.h"
#include<iostream>
using namespace std;
#include<string>
#include"Match.h"
PUBG::PUBG()
{
	match = new Match*[50];
	size = 0;
}
void PUBG::AddGame(Match *mat)
{
	int i = 0;
	Match **temp = this->match;
	for (i = 0; i < size; i++)
	{
		match[i] = temp[i];
	}
	match[i] = mat;
	size++;
}
void PUBG::Display()
{
	for (int i = 0; i < size; i++)
	{
		match[i][0].Display();
	}
}
PUBG::~PUBG()
{
}
