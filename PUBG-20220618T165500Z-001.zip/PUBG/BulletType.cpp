#include "BulletType.h"
#include<string>
#include<iostream>
using namespace std;
BulletType::BulletType()
{
	firerate = 0;
	maxsize = 0;
	range = 0;
	bullets = 0;
	bullettype = "medium";
}
BulletType::BulletType(string type, int firerate, int maxsize, int range, int bullets)
{
	this->bullettype = type;// using string,,,,,
	this->maxsize = maxsize;
	this->range = range;
	this->bullets = bullets;
	this->firerate = firerate;
}
void BulletType::SetBulletType(string type)
{
	this->bullettype = type;
}
void BulletType::SetBullets(int  bults)
{
	this->bullets = bults;
}
void BulletType::SetFirerate(int f)
{
	this->firerate = f;
}
void BulletType::SetMaxSize(int m)
{
	this->maxsize = m;
}
void BulletType::SetRange(int r)
{
	this->range = r;
}
BulletType::BulletType(BulletType &obj)
{
	this->bullettype = obj.bullettype;
	this->maxsize = obj.maxsize;
	this->range = obj.range;
	this->firerate = obj.firerate;
	this->bullets = obj.bullets;
}
string BulletType::getBultesType()
{
	return this->bullettype;
}
int BulletType::GetBullets()
{
	return this->bullets;
}
int BulletType::GetFireRate()
{
	return this->firerate;
}
int BulletType::GetRange()
{
	return this->range;
}
int BulletType::GetMaxSize()
{
	return this->maxsize;
}
void BulletType::print()
{
	cout << "BulletType: ";
	cout << this->bullettype;
	cout << endl << "Total Bullets: " << this->bullets << endl;
	cout << "Range : " << this->range << endl;
	cout << "MaxSize: " << this->maxsize << endl;
	cout << "FireRate: " << this->firerate << endl;
}
BulletType::~BulletType()
{
}
