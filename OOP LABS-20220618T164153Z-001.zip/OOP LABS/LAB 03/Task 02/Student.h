#pragma once
class Student
{
	int size1 = 0;
	int size2 = 0;
	char *fname;
	char *lname;
	static int count;
public:
	Student();
	Student(char*, char*);
	int  inc();
	void print();
};