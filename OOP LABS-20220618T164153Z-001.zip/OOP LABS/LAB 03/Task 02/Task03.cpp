#include<iostream>
#include"Student.h"
using namespace std;
int Student::count = { 0 };
int main()
{
	char *fname = new char[30];
	char *lname = new char[30];
	cout << "Enter Your First Name: ";
	cin >> fname;
	cout << "Enter Your Last Name: ";
	cin >> lname;
	Student *obj1=new Student(fname, lname);
	cout << "Enter Your First Name: ";
	cin >> fname;
	cout << "Enter Your Last Name: ";
	cin >> lname;
	Student *obj2 = new Student(fname, lname);

	return 0;
}