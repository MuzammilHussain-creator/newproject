#include<iostream>
#include "RectAngle.h"
using namespace std;
RectAngle::RectAngle()
{
	length = 1;
	widht = 1;
}
void RectAngle::setLength(float x)
{
	if (x > 0 && x <= 20)
		length = x;
}
int RectAngle::getLength()
{
	return length;
}
void RectAngle::CaluclateArea(float length,float widht)
{
	float area=0.0;
	area = (0.5)*(length)*(widht);
	cout << "Area: "<<area << endl;
}
void RectAngle::setWidth(float y)
{
	if (y > 0 && y <= 20)
		widht = y;
}
int RectAngle::getWidth()
{
	return widht;
}
void RectAngle::Parameter(float length, float widht)
{
	float para = 0;
	para = length + widht;
	cout << "Para: " << para << endl;
}
RectAngle::~RectAngle()
{

}

