#include<iostream>
#include"student.h"
using namespace std;
student::student(char *name, char *address, char *phone, char *department)
{
	int size1 = 0, size2 = 0, size3 = 0, size4 = 0;
	size1 = strlen(name);
	size2 = strlen(address);
	size3 = strlen(phone);
	size4 = strlen(department);
	this->name = new char[size1 + 1];
	this->address = new char[size2 + 1];
	this->phone = new char[size3 + 1];
	this->department = new char[size4 + 1];
	int i = 0;
	for (i = 0; i < size1; i++)
	{
		this->name[i] = name[i];
	}
	name[i] = NULL;
	for (i = 0; i < size2; i++)
	{
		this->address[i] = address[i];
	}
	for (i = 0; i < size3; i++)
	{
		this->phone[i] = phone[i];
	}
	for (i = 0; i < size4; i++)
	{
		this->department[i] = department[i];
	}
	delete[] name;
	name = nullptr;
	delete[] address;
	address = nullptr;
	delete[] phone;
	phone = nullptr;
	delete[] phone;
	phone = nullptr;

}
student::student(float subj1, float subj2, float subj3)
{
	this->subj1 = subj1;
	this->subj2 = subj2;
	this->subj3 = subj3;
	float sum = (this->subj1 + this->subj2 + this->subj3);
	aveg = (sum / 6)*(100);

	if (aveg >= 80 && aveg <= 100)
	{
		cout << "CGPA" << "4";
	}
	if (aveg >= 60 && aveg <= 79)
	{
		cout << "CGPA" << "3";
	}
	if (aveg >= 50 && aveg <= 59)
	{
		cout << "CGPA" << "2";
	}
	if (aveg > 49)
	{
		cout << "Fail: ";
	}
}
