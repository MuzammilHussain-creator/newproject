#pragma once
class student
{
	char *name;
	char *address;
	char *phone;
	char *department;
	float subj1;
	float subj2;
	float subj3;
	int size1, size2, size3;
	float aveg;
public:
	student(char*, char*, char*, char*);
	student(float, float, float);
};