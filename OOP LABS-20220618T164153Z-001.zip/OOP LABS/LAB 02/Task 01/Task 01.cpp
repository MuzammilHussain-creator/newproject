#include<iostream>
#include "RectAngle.h"
using namespace std;

int main()
{
	RectAngle obj;
	float a = 0,b=0;
	cout << "Enter Length: ";
	cin >> a;
	obj.setLength(a);
	cout << "Enter Widht: ";
	cin >> b;
	obj.setWidth(b);
	obj.CaluclateArea(a, b);
	obj.Parameter(a, b);
	return 0;
}