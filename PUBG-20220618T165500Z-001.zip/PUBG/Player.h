#pragma once
#include<iostream>
#include"Weapon.h"
#include<string>
using namespace std;
class Player
{
	string name;
	string costume;
	string id;
	string parachute;
	string health;
	Weapon **weapon;
	int size = 0;
public:
	Player();
	Player(string, string, string, string, string);
	void Add_Player(Weapon *weapon);
	void Player_Display();
	~Player();
};

