#pragma once
#include<iostream>
using namespace std;
#include<string>
#include"Lobby.h"
class Match
{
	Lobby **lobby;
	int type;
	int size = 0;
public:
	Match();
	Match(int a);
	void addlobby(Lobby *lobby);
	void Display();
	~Match();
};

