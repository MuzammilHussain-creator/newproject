#include<iostream>
#include<string>
#include "Player.h"
#include"Lobby.h"
#include"Match.h"
#include"BulletType.h"
#include"Weapon.h"
#include"PUBG.h"
using namespace std;
int Lobby::veriable = { 0 };
int main()
{
	int type;
	Player P1("Muzamal", "Strong", "L1f18bscs0498", "Penshirt", "Cruciform");
	Player P2("Muzamal", "Strong", "L1f18bscs0498", "Penshirt", "Cruciform");
	Player P3("Muzamal", "Strong", "L1f18bscs0498", "Penshirt", "Cruciform");
	Player P4("Muzamal", "Strong", "L1f18bscs0498", "Penshirt", "Cruciform");
	Lobby lobby1,lobby2,lobby3;
	lobby1.Addplayer(&P1);
	lobby1.Addplayer(&P2);
	lobby2.Addplayer(&P3); 
	lobby2.Addplayer(&P4);
	lobby3.Addplayer(&P4);
	lobby1.Remove_Player(&P1);
	lobby1.PartyLeader(&P3);
	cout << "Enter 1 For Solo Loby,2 For Dua Lobby, 3 For Squad Lobby: ";
	cin >> type;
	Match M1(type);
	M1.addlobby(&lobby1);
	M1.addlobby(&lobby2);
	M1.addlobby(&lobby3);
	cout << endl;
	BulletType B1("Medium",2, 50, 150, 30);
	Weapon W1(B1);
	W1.Set_Weapon_Name("Pistol");
	P1.Add_Player(&W1);
	P1.Add_Player(&W1);
	P2.Add_Player(&W1);
	P2.Add_Player(&W1);
	P2.Add_Player(&W1);
	P1.Player_Display();//Print Function
	P2.Player_Display();//Print Function
	PUBG MainGame;
	MainGame.AddGame(&M1);
	MainGame.Display();// Main Print Function
	return 0;
}