#include<iostream>
using namespace std;
#include<string>
#include "Lobby.h"
#include"Player.h"
Lobby::Lobby()
{
	player= new Player*[4];
	leader = new Player*[1];
	size = 0;

}
void Lobby::Addplayer(Player *play)
{
	char a = 't';
	int i = 0;
	bool flag = true;
	function();
	Player **Temp = player;
	for (i = 0; i < size; i++)
	{
		if (size >= 4)
		{
			cout << "Size Out Of Bond: " << endl;
			break;
		}
		if (player[i] != play)
		{
			flag = true;
		}
		else
		{
			flag = false;
			break;
		}
	}
	if (flag == true)
	{
		if (size == 0)
		{
			PartyLeader(play);
		}
		if (size < 4)
		{
			for (i = 0; i < size; i++)
			{
				player[i] = Temp[i];
			}
			player[i] = play;
			size++;
		}
		if (size > 4)
		{
			cout << "Lobby Has Already Four Players: " << endl;
		}
	}
	else
	{
		cout << "Already Exsit: " << endl;
	}
}
void Lobby::Remove_Player(Player *play)
{
	Player **temp;
	int j = 0;
	temp = new Player*[4];
	for (int i = 0; i < size; i++)
	{
		if (player[i] != play)
		{
			temp[j] = player[i];
			j++;
		}
	}
	for (int i = 0; i < size; i++)
	{
		if (player[i] == play)
		{
			size--;
		}
	}
	for (int i = 0; i < size; i++)
	{
		player[i] = nullptr;
	}
	for (int i = 0; i < size; i++)
	{
		player[i] = temp[i];
	}
	PartyLeader(player[0]);
	D_function();

}
void Lobby::PartyLeader(Player *play)
{
	leader[0] = play;
}
void Lobby::Print_Party_Leader()
{
	if (size != 0)
	{
		cout << "Party Leader: " << endl;
		cout << "*************************************" << endl;
		leader[0][0].Player_Display();
		cout << endl;
		cout << "**************************************" << endl;
	}
	else
	{
		cout << "There Is No Party Leader: " << endl;
	}
}
void Lobby::function()
{
	veriable++;
}
void Lobby::D_function()
{
	veriable--;
}
void Lobby::Print()
{
	for (int i = 0; i < size; i++)
	{
		player[i][0].Player_Display();
		cout << endl;
	}
}
Lobby::~Lobby()
{
}
