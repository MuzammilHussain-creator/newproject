#pragma once
#include "OneD.h"
class Triangle :
	public OneD
{
protected:
	int z;
public:
	Triangle(string,Point,Point,int);
	void Draw();
	void Print();
	~Triangle();
};

