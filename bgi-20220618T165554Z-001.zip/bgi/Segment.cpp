#include "Segment.h"
#include "graphics.h"

Segment::Segment(string n, Point p1, Point p2) :OneD(n, p1, p2)
{
}
void Segment::Draw()
{
	line(p1.GetX(), p1.GetY(), p2.GetX(), p2.GetY());
}
void Segment::Print()
{
	cout << "In Segment: " << endl;
}

Segment::~Segment()
{
}
