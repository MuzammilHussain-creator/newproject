#pragma once
#include<iostream>
using namespace std;
class rectangle
{
	int real;
	int imaginary;
	friend istream& operator>>(istream& input,rectangle& obj);
	friend ostream& operator<<(ostream& ouput, rectangle& obj);
public:

	rectangle();
	int complax (rectangle& obj);
	void display();
	~rectangle();
};

