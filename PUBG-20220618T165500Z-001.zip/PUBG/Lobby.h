#pragma once
#include<iostream>
using namespace std;
#include<string>
#include"Player.h"
class Lobby
{
	Player **player;
	Player **leader;
	int size;
	static int veriable;
public:
	Lobby();
	void Addplayer(Player *plyer);
	static void function();
	static void D_function();
	void operator<<(ostream &out);
	void PartyLeader(Player *player);
	void Remove_Player(Player *play);
	void Print_Party_Leader();
	void Print();
	~Lobby();
};

