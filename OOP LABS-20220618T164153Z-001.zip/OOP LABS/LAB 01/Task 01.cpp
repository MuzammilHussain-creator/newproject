#include<iostream>
#include<fstream>
using namespace std;
void Search(int **matrix, int **minMatrix, int **maxMatrix,int &row,int &col,ofstream &fout);
int main()
{
	int num = 0;
	int row=0,col=0;
	ofstream fout;
	fout.open("output.txt");
	ifstream fin;
	fin.open("matrix.txt");
	fin>>row;
	fin>>col;
	int **matrix=new int*[row];
	for(int i=0;i<row;i++)
	{
		matrix[i]=new int[col];
	}
	int **minMatrix=new int*[row];
	for(int i=0;i<row;i++)
	{
		minMatrix[i]=new int[1];
	}
	int **maxMatrix=new int*[1];
	for(int i=0;i<row;i++)
	{
		maxMatrix[i]=new int[col];
	}
	for (int i = 0; i<row; i++)
	{
		for (int j = 0; j<col; j++)
		{
			fin >> num;
			matrix[i][j] = num;
		}
	}
	fout<<"Original Matrix: "<<endl;
	for(int i=0;i<row;i++)
	{
		for(int j=0;j<col;j++)
		{
			fout<<matrix[i][j]<<" ";
		}
		fout<<endl;
	}
	Search(matrix,minMatrix,maxMatrix,row,col,fout);
	return 0;
}
void Search(int **matrix, int **minMatrix, int **maxMatrix,int &row,int &col,ofstream &fout)
{
	int k=0;
	int *temp=new int[row];
	for(int i=0;i<row;i++)
	{
		for(int j=0;j<col;j++)
		{
			temp[j]=matrix[i][j];
		}
		int tem=temp[0];
		minMatrix[k][0]=tem;
		for(int j=0;j<row;j++)
		{
			if(tem>temp[j])
			{
				tem=temp[j];
				minMatrix[k][0]=tem;
			}
		}
		k++;
	}
	fout<<"Mini Matrix: "<<endl;
	for(int i=0;i<row;i++)
	{
		for(int j=0;j<1;j++)
		{
			fout<<minMatrix[i][j];
		}
		fout<<endl;
		
	}
	k=0;
	temp=new int[col];
	for(int i=0;i<col;i++)
	{
		for(int j=0;j<row;j++)
		{
			temp[j]=matrix[j][i];
		}
		int tem=temp[0];
		maxMatrix[0][k]=tem;
		for(int j=0;j<col;j++)
		{
			if(tem<temp[j])
			{
				tem=temp[j];
				maxMatrix[0][k]=tem;
			}
		}
		k++;
	}
	fout<<"MaxMatrix: "<<endl;
	for(int i=0;i<1;i++)
	{
		for(int j=0;j<col;j++)
		{
			fout<<maxMatrix[0][j]<<" ";
		}
		fout<<endl;
	}
}
