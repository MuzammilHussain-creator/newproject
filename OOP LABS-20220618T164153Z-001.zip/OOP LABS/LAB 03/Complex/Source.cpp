#include<iostream>
#include"rectangle.h"
using namespace std;
int main()
{
	rectangle obj;
	int num = 0;
	cout << "Number1: ";
	cin >> obj;
	cout << "Number1: ";
	cin >> obj;
	obj.complax(obj);
	obj.display();
	/*rectangle obj1(obj);
	obj1.complax(obj);*/
	return 0;
}