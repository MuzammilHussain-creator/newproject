#include<iostream>
#include"DayType.h"
using namespace std;
int main()
{
	int z = 0, y = 0, l = 0;
	DayType obj;
	cout << "Enter Your SetDay: ";
	cin >> z;
	obj.setDay(z);
	obj.RetDay();
	cout << "Enter Your Next Day: ";
	cin >> y;
	obj.Next_Day(y);
	obj.RetDay();
	cout << "Enter Your Previous Day: ";
	cin >> l;
	obj.Prev_Day(l);
	obj.Ret_Prev();
	cout << "Peresent Day is   : ";
	obj.printDay();
	cout << "Your Next Day is   : ";
	obj.prinNext();
	cout << "Your Previous Day is : ";
	obj.prinPrev();

	return 0;
}