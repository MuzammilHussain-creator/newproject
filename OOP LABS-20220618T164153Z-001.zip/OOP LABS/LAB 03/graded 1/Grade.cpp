#include<iostream>
#include"student.h"
using namespace std;
int main()
{
	float subj1 = 0;
	float subj2 = 0;
	float subj3 = 0;
	char *name = new char[30];
	char *address = new char[30];
	char *phone = new char[30];
	char *department = new char[30];
	cout << "Enter Name: ";
	cin >> name;
	cout << "Enter ADRESS: ";
	cin >> address;
	cout << "Enrer Phone: ";
	cin >> phone;
	cout << "Enter Department: ";
	cin >> department;
	cout << "Enter Subj1 Marks: ";
	cin >> subj1;
	cout << "Enter Subj2 Marks: ";
	cin >> subj2;
	cout << "Enter Subj3 Marks: ";
	cin >> subj3;
	student obj(name, address, phone, department);
	student obj1(subj1, subj2, subj3);
}