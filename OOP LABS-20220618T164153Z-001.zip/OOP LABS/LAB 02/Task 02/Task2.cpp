#include<iostream>
#include"SwimingPool.h"
using namespace std;
int main()
{
	SwimingPool obj;
	float x = 0, y = 0, z = 0, u = 0,w=0;
	cout << "Enter Length: ";
	cin >> x;
	obj.setLen(x);
	cout << "Enter Depth: ";
	cin >> y;
	obj.setDep(y);
	cout << "Enter Width: ";
	cin >> z;
	obj.setWid(z);
	cout << "Enter Rate: ";
	cin >> w;
	obj.setRate(w);
	obj.CalVol(x, y, z, u);
	obj.CalTime(w);
	return 0;
}