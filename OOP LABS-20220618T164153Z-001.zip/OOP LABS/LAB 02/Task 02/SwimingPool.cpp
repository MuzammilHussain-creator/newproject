#include<iostream>
#include"SwimingPool.h"
using namespace std;
SwimingPool::SwimingPool()
{

}
void SwimingPool::setLen(float a)
{
	length = a;
}
int SwimingPool::getLen()
{
	return length;
}
void SwimingPool::setWid(float b)
{
	width = b;
}
int SwimingPool::getWid()
{
	return width;
}
void SwimingPool::setDep(float c)
{
	depth = c;
}
int SwimingPool::getDep()
{
	return depth;
}
void SwimingPool::setRate(float d)
{
	rate = d;
}
int SwimingPool::getRate()
{
	return rate;
}
int SwimingPool::CalVol(float length, float width, float depth,float vol)
{
	vol = length*width*depth;
	cout << "Volume: " << vol << endl;
	return vol;
}
void SwimingPool::CalTime( float rate)
{
	float time = 0;
	float VOL = 0;
	VOL=CalVol(length,width,depth,vol);
	time = (VOL / rate);
	cout << "Time: " << time<<endl;
}
SwimingPool::~SwimingPool()
{

}