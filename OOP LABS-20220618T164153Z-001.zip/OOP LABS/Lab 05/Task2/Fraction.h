#pragma once
#include <iostream>
using namespace std;
class Fraction
{
	int num;
	int den;
public:
	void display();
	Fraction(int, int);
	Fraction();
	Fraction operator+(Fraction);
	Fraction operator-(Fraction);
	Fraction operator*(Fraction);
	bool operator==(Fraction);
	bool operator!=(Fraction);
	bool operator>(Fraction);
	bool operator<(Fraction);
	~Fraction();
};


