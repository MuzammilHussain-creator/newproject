#include<iostream>
#include<fstream>
using namespace std;
void Function(int matrix[5][5],int minMatrix[5][1],ofstream &fout);
void sorting(int index[5],int &i,int &j);
int main()
{
	int matrix[5][5];
	int num;
	int minMatrix[5][1];
	ofstream fout;
	fout.open("output.txt");
	ifstream fin;
	fin.open("matrix.txt");
	for(int i=0;i<5;i++)
	{
		for(int j=0;j<5;j++)
		{
			fin>>num;
			matrix[i][j]=num;
		}
	}
	fout<<"Original Array: "<<endl;
	for(int i=0;i<5;i++)
	{
		for(int j=0;j<5;j++)
		{
			fout<<matrix[i][j]<<" ";
		}
		fout<<endl;
	}
	cout<<endl;
	Function(matrix,minMatrix,fout);
	return 0; 
}
void Function(int matrix[5][5],int minMatrix[5][1],ofstream &fout)
{
	int temp=0;
	int k=0;
	for(int i=0;i<5;i++)
	{
		temp=matrix[i][0];
		for(int j=0;j<5;j++)
		{
			if(j==0)
			{
				minMatrix[k][0]=matrix[i][0];
			}
			if(temp>matrix[i][j])
			{
				temp=matrix[i][j];
				minMatrix[k][0]=temp;
			}
		}
		k++;
	}
	fout<<"MinMatrix"<<endl;
	for(int i=0;i<5;i++)
	{
		for(int j=0;j<1;j++)
		{
			fout<<minMatrix[i][j];
		}
		fout<<endl;
	}
	int D1[5];
	int index[5];
	for(int i=0;i<5;i++)
	{
		for(int j=0;j<1;j++)
		{
			D1[i]=minMatrix[i][j];
		}
	}
	for(int i=0;i<5;i++)
	{
		index[i]=i;
	}
	k=0;
	for(int i=0;i<5;i++)
	{
		for(int j=0;j<5;j++)
		{
			if(D1[i]<D1[j])
			{
				temp=D1[i];
				D1[i]=D1[j];
				D1[j]=temp;
				sorting(index,i,j);
			}
		}
		k++;
	}
	for(int i=0;i<5;i++)
	{
		for(int j=0;j<1;j++)
		{
			minMatrix[i][j]=D1[i];
		}
	}
	fout<<"After Sorting The minMatrix: "<<endl;
	for(int i=0;i<5;i++)
	{
		for(int j=0;j<1;j++)
		{
			fout<<minMatrix[i][j]<<" ";
		}
		fout<<endl;
	}
	fout<<"After Sorting : "<<endl;
	for(int i=0;i<5;i++)
	{
		for(int j=0;j<5;j++)
		{
			fout<<matrix[index[i]][j]<<" ";
		}
		fout<<endl;
	}
}
void sorting(int index[5],int &i,int &j)
{
	int temp=0;
	temp=index[i];
	index[i]=index[j];
	index[j]=temp;
}
