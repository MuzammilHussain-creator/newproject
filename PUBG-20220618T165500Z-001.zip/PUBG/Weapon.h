#pragma once
#include<iostream>
using namespace std;
#include<string>
#include"BulletType.h"
class Weapon
{
	BulletType bult;
	string WeaponName;
public:
	Weapon();
	void Set_Weapon_Name(string);
	string Get_Weapon_Name();
	Weapon(BulletType B);
	Weapon(Weapon &obj);
	void print();
	~Weapon();
};

