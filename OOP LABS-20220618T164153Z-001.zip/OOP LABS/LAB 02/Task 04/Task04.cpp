#include<iostream>
#include"TimeType.h"
using namespace std;
int main()
{
	TimeType obj;
	TimeType obj1;
	int h = 0, m = 0, s = 0;
	int hr = 0, mt = 0, st = 0;
	cout << "Enter Hours: ";
	cin >> h;
	cout << "Enter Mintues: ";
	cin >> m;
	cout << "Enter Seconds: ";
	cin >> s;
	obj.SetTime(h, m, s);
	obj.GetTime(h,m,s);
	cout << "Before:  ";
	obj.PrintTime();
	cout << "After:  ";
	obj.IncrSecond();
	obj.PrintTime();
	cout << "Enter Hours: ";
	cin >> hr;
	cout << "Enter Mintues: ";
	cin >> mt;
	cout << "Enter Seconds: ";
	cin >> st;
	obj1.SetTime(hr, mt, st);
	obj1.equalTime(obj1,obj);
	return 0;
}