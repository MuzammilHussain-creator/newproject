#include "Fraction.h"

Fraction::Fraction()
{
	num = 0;
	den = 1;
}
void Fraction::display()
{
	cout << num << "/" << den << endl;
}

Fraction::Fraction(int n, int d)
{
	if (d == 0)
		d = 1;
	num = n;
	den = d;
}
Fraction Fraction::operator+(Fraction obj)
{
	Fraction res;
	int gcd;
	res.num = num*obj.den + obj.num*den;
	res.den = den*obj.den;
	for (int i = 1; i <= res.num&&i <= res.den; i++)
	{
		if (res.num%i == 0 && res.den%i==0)
		{
			gcd = i;
		}
	}
	res.num = res.num / gcd;
	res.den = res.den / gcd;
	return res;
}
Fraction Fraction::operator-(Fraction obj)
{
	int gcd = 0;
	Fraction res;
	int k = 0, l = 0;
	res.num = num*obj.den - obj.num*den;
	res.den = den*obj.den;
	return res;
}
Fraction Fraction::operator*(Fraction obj)
{
	int gcd = 0;
	Fraction res;
	res.num = num*obj.num;
	res.den = den*obj.den;
	for (int i = 1; i <= res.num&&i <= res.den; i++)
	{
		if (res.num%i == 0 && res.den%i == 0)
		{
			gcd = i;
		}
	}
	res.num = res.num / gcd;
	res.den = res.den / gcd;
	return res;
}
bool Fraction::operator==(Fraction obj)
{
	double a, b, c, d;
	a = num;
	b = den;
	c = obj.num;
	d = obj.den;
	return (a/b==c/d);
}
bool Fraction::operator!=(Fraction obj)
{
	int gcd = 0;
	double a, b, c, d;
	a = num;
	b = den;
	c = obj.num;
	d = obj.den;
	return (a / b != c / d);
}
bool Fraction::operator>(Fraction obj)
{
	int gcd = 0;
	double a, b, c, d;
	a = num;
	b = den;
	c = obj.num;
	d = obj.den;
	return (a / b > c / d);
}
bool Fraction::operator<(Fraction obj)
{
	int gcd = 0;
	double a, b, c, d;
	a = num;
	b = den;
	c = obj.num;
	d = obj.den;
	return (a / b < c / d);
}
Fraction::~Fraction(void)
{
}
