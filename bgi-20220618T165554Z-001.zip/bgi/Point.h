#pragma once
#include "Shapes.h"
#include<iostream>
using namespace std;
#include<string>
class Point :
	public Shapes
{
protected:
	int x;
	int y;
public:
	Point(string,int,int);
	void Draw();
	void Print();
	void SetX(int);
	int GetX();
	void SetY(int);
	int GetY();
	~Point();
};

