#include "Weapon.h"
#include<string>
#include"BulletType.h"
using namespace std;
Weapon::Weapon()
{
	WeaponName = "AK47";
}
void Weapon::Set_Weapon_Name(string name)
{
	this->WeaponName = name;
}
string Weapon::Get_Weapon_Name()
{
	return this->WeaponName;
}
Weapon::Weapon(Weapon &obj)
{
	this->WeaponName = obj.WeaponName;
}
Weapon::Weapon(BulletType b) : bult(b){

}
void Weapon::print()
{
	cout << "Weapon Name: " << this->WeaponName << endl;
	bult.print();
}
Weapon::~Weapon()
{
}
