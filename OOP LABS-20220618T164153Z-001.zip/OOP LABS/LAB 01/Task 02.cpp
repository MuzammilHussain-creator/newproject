#include<iostream>
#include<fstream>
using namespace std;
void Function(	int matrix1[6][6],	int matrix2[3][4],ofstream &fout);
int main()
{
	int matrix1[6][6];
	int matrix2[3][4];
	int num=0;
	ifstream fin1,fin2;
	ofstream fout;
	fin1.open("matrix1.txt");
	fin2.open("matrix2.txt");
	for(int i=0;i<6;i++)
	{
		for(int j=0;j<6;j++)
		{
			fin1>>num;
			matrix1[i][j]=num;
		}
	}
		for(int i=0;i<3;i++)
	{
		for(int j=0;j<4;j++)
		{
			fin2>>num;
			matrix2[i][j]=num;
		}
	}
	fin1.close();
	fout.open("output.txt");
	Function(matrix1,matrix2,fout);
	
}
void Function(	int matrix1[6][6],	int matrix2[3][4],ofstream &fout)
{
	int size1=6;
	int size2=4;
	int size=6-4;
	for(int i=0;i<3;i++)
	{
		int size1=6;
     	int size2=4;
		for(int j=0;j<4;j++)
		{
			matrix1[i][size1-1]=matrix2[i][size2-1];
			size1--;
			size2--;
		}
	}
	fout<<"After Sorting Matrix1: "<<endl;
	for(int i=0;i<6;i++)
	{
		for(int j=0;j<6;j++)
		{
			fout<<matrix1[i][j]<<" ";
		}
		fout<<endl;
	}
}
