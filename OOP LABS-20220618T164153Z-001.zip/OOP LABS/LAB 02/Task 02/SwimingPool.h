#pragma once

class SwimingPool
{
private:
	float length = 0, width = 0, depth = 0,rate=0,vol=0;
public:
	SwimingPool();
	void setLen(float);
	int getLen();
	void setWid(float);
	int getWid();
	void setDep(float);
	int getDep();
	void setRate(float);
	int getRate();
	int CalVol(float, float, float,float);
	void CalTime(float);
	~SwimingPool();


};
