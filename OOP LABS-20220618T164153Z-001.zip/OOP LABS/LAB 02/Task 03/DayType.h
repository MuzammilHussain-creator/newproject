#pragma once

class DayType
{
private:
	int day = 0;
	int nextday = 0;
	int preday = 0;
public:
	DayType();
	void setDay(int);
	void printDay();
	void prinPrev();
	void prinNext();
	int RetDay();
	void Next_Day(int);
	int Next_Ret();
	void Prev_Day(int);
	int Ret_Prev();
	~DayType();

};