#pragma once
#include"OneD.h"
#include "Shapes.h"
class Segment:public OneD
{
public:
	Segment(string,Point,Point);
	void Draw();
	void Print();
	~Segment();
};

