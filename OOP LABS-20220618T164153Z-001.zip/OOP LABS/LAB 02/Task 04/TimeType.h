#pragma once
class TimeType
{
private:
	int hours = 0, mintues = 0, seconds = 0;
public:
	TimeType();
	void SetTime(int, int, int);
	void GetTime(int&,int&,int&)const;
	void PrintTime();
	void IncrHourse();
	void IncrMintues();
	void IncrSecond();
	bool equalTime(const TimeType&,const TimeType&)const;
	~TimeType();
};