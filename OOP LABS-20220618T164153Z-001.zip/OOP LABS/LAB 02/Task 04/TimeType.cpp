#include<iostream>
#include"TimeType.h"
using namespace std;
TimeType::TimeType()
{

}
void TimeType::SetTime(int h, int m, int s)
{
	hours = h;
	mintues = m;
	seconds = s;
}
void TimeType::GetTime(int &h,int &m,int &s)const
{
	h = hours;
	m = mintues;
	s = seconds;
}
void TimeType::PrintTime()
{
	cout << hours << ":" << mintues << ":" << seconds << endl;
}
void TimeType::IncrHourse()
{
	if (hours > 23)
		hours = 0;
	else
	hours++;
}
void TimeType::IncrMintues()
{
	if (mintues > 59)
	{
		mintues = 0;
		IncrHourse();
	}
	else
	{
		mintues++;
	}
}
void TimeType::IncrSecond()
{
	if (seconds > 59)
	{
		seconds = 0;
		IncrMintues();
	}
	else
	{
		seconds++;
	}
}
bool TimeType::equalTime(const TimeType& obj1,const TimeType& obj)const
{
	if (obj1.hours ==obj.hours&&obj1.seconds == obj.seconds&&obj1.mintues == obj.mintues)
	{
		cout << "Equal Time: " << endl;
		return true;
	}
	else
	{
		cout << "Not Equal Time: " << endl;
		return false;
	}
}
TimeType::~TimeType()
{

}