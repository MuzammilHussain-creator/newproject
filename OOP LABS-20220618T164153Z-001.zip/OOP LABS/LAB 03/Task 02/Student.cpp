#include<iostream>
using namespace std;
#include"Student.h";
Student::Student(char *fname, char *lname)
{
	size1 = 0;
	size2 = 0;
	size1 = strlen(fname);
	this->fname = new char[size1 + 1];
	size2 = strlen(lname);
	this->lname = new char[size2 + 1];
	for (int i = 0; i < size1; i++)
	{
		this->fname[i] = fname[i];
	}
	for (int i = 0; i < size2; i++)
	{
		this->lname[i] = lname[i];
	}
	inc();
	print();
	delete [] fname;
	fname = nullptr;
	delete [] lname;
	lname = nullptr;
}
int Student::inc()
{
	count++;
	return count;
}
void Student::print()
{
	cout << count << this->fname;
}
