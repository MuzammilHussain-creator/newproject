#include <iostream>
#include <fstream>
using namespace std;
void Acending(int **arr,int row,int col);
void Decending(int **arr,int row,int col);
void Display(int **arr,int &row,int &col);
int main()
{
	int num=0;
	int i=0;
	int j=0;
	ifstream fin;
	fin.open("input.txt");
	while(fin)
	{
		fin>>i;
		num++;
	}
	num=num-1;
	int integ;
	int num1=num;
	int row=0;
	int col=0;
	for(int i=0;i<num/2;i++)
	{
		if(i*i==num1)
		{
			row=i;
			col=i;
			break;
		}
		else
		{
			for(j=0;j<=i;j++)
			{
				if(i*j>=num1)
				{
					row=i;
					col=j;
					break;
				}
				if(i*j>=num1)
				break;
			}
		}
		if(i*j>=num1)
		break;
	}
	int **arr=new int*[row];
	for(int i=0;i<row;i++)
	{
		arr[i]=new int[col];	
	}
	fin.close();
	fin.open("input.txt");
	int c=0;
	for(int i=0;i<row;i++)
	{
		for(int j=0;j<col;j++)
		{
			fin>>integ;
			arr[i][j]=integ;
			c++;
			if(c>num)
			{
				arr[i][j]=-1;
			}
		}
	}
	Acending(arr,row,col);
	Decending(arr,row,col);
	Display(arr,row,col);
	return 0;
}
void Acending(int **arr,int row,int col)
{
	int temp[row];
	int k=0,l=0;
	for(int i=0;i<row;i++)
	{
		if(i%2==1)
		{
			for(int j=0;j<col;j++)
			{
				temp[k]=arr[i][j];
				k++;
			}
			for(int j=0;j<k;j++)
			{
				for(int h=0;h<k;h++)
				{
					if(temp[j]<temp[h])
					{
						l=temp[j];
						temp[j]=temp[h];
						temp[h]=l;
					}
				}
			}
			for(int j=0;j<k;j++)
			{
				arr[i][j]=temp[j];
			}
		}
		k=0;
	}
}
void Decending(int **arr,int row,int col)
{
	int temp[row];
	int k=0,l=0;
	for(int i=0;i<row;i++)
	{
		if(i%2==0)
		{
			for(int j=0;j<col;j++)
			{
				temp[k]=arr[i][j];
				k++;
			}
			for(int j=0;j<k;j++)
			{
				for(int h=0;h<k;h++)
				{
					if(temp[j]>temp[h])
					{
						l=temp[j];
						temp[j]=temp[h];
						temp[h]=l;
					}
				}
			}
			for(int j=0;j<k;j++)
			{
				arr[i][j]=temp[j];
			}
		}
		k=0;
	}
}
void Display(int **arr,int &row,int &col)
{
	ofstream fout;
	fout.open("output.txt");
	cout<<endl;
	fout<<"After Sorting : "<<endl;
	for(int i=0;i<row;i++)
	{
		for(int j=0;j<col;j++)
		{
			fout<<arr[i][j]<<"\t";
		}
		fout<<endl;
	}
}
