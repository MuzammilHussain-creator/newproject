#include "Shape.h"
#include <iostream>
using namespace std;

Shape::Shape()
{
	name = "\0";
}



Shape::~Shape()
{
}

Shape::Shape(string s)
{
	name = s;
}

void Shape::print()
{
	cout << "In shape" << endl;
}