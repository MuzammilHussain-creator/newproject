#include<iostream>
#include"Mystringj.h"
using namespace std;
int main()
{
	char *arr = nullptr;
	arr = new char[50];
	for (int i = 0; i < 50; i++)
	{
		arr[i] = '\0';
	}
	cout << "Enter String: ";
	cin >> arr;
	Mystringj obj(arr);
	for (int i = 0; i < 50; i++)
	{
		arr[i] = '\0';
	}
	cout << "Enter String: ";
	cin >> arr;
	Mystringj obj2;
	obj2.setMyarr(arr);
	cout << "Array: ";
	cout << obj2.getMyarr();
	cout << endl;
	cout << "Size: ";
	cout << obj2.getsize();
	cout << endl;
	obj2.print();
	Mystringj obj3;
	obj3 = obj + obj2;
	cout << endl;
	obj = obj + obj2;
	cout << endl;
	return 0;
}