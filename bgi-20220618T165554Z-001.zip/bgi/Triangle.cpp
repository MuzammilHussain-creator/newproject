#include "Triangle.h"
#include"graphics.h"

Triangle::Triangle(string n, Point p1, Point p2, int p3) :OneD(n, p1, p2), z(p3)
{
}
void Triangle::Draw()
{
	
}
void Triangle::Print()
{
	cout << "In Triangle: " << endl;
}

Triangle::~Triangle()
{
}
