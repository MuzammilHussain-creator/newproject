#pragma once
#include<iostream>
using namespace std;
#include<string>
#include"Match.h"
class PUBG
{
	Match **match;
	int size = 0;
public:
	PUBG();
	void AddGame(Match *ma);
	void Display();
	~PUBG();
};

