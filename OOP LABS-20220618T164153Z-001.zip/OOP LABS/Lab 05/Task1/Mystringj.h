#pragma once
class Mystringj
{
	char *arr;
	int size;
public:
	Mystringj();
	Mystringj(char*);
	void setMyarr(char*);
	const char* getMyarr() const;
	const int getsize()const;
	void print()const;
	Mystringj operator+(Mystringj& obj2);
	Mystringj operator+=(Mystringj& obj2);
	~Mystringj();
};

