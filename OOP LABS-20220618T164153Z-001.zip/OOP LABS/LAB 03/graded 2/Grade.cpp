#include<iostream>
#include<fstream>
#include"student.h"
using namespace std;
int student::count = { 0 };
int main()
{
	char *name = new char[30];
	char *Anumber = new char[30];
	char *Atype = new char[30];
	ofstream fout;
	fout.open("output.txt", ios::app);
	float mony = 0;
	int day = 0;
	cout << "Enter Name: ";
	cin >> name;
	cout << "Enter Account Number: ";
	cin >> Anumber;
	cout <<  "Enter Account Type: ";
	cin >> Atype;
	cout << "Enter Day: ";
	cin >> day;
	cout << "Enter Money: ";
	cin >> mony;
	student obj(name,Anumber,Atype,mony,day);
	obj.NAMES();
	fout << obj.days();
}