#pragma once
#include "Shapes.h"
#include"Point.h"
class OneD :
	public Shapes
{
protected:
	Point p1;
	Point p2;
public:
	OneD(string, Point, Point);
	void Print();
	~OneD();
};

