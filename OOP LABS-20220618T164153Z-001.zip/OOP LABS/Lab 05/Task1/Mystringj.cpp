#include "Mystringj.h"
#include<iostream>
using namespace std;

Mystringj::Mystringj()
{
	size = 0;
	arr = nullptr;
}
Mystringj::Mystringj(char* arr)
{
	for (int i = 0; arr[i] != '\0'; i++)
	{
		size++;
	}
	this->arr = new char[size];
	for (int i = 0; i < size; i++)
	{
		this->arr[i] = arr[i];
	}
	this->arr[size] = '\0';
}
void Mystringj::setMyarr(char *arr)
{
	size = 0;
	for (int i = 0; arr[i] != '\0'; i++)
	{
		size++;
	}
	this->arr = new char[size];
	for (int i = 0; i < size; i++)
	{
		this->arr[i] = arr[i];
	}
	this->arr[size] = '\0';
}

const char* Mystringj::getMyarr()const
{
	return this->arr;
}
const int Mystringj::getsize()const
{
	return this->size;
}
void Mystringj::print()const
{
	cout << "size: " << this->size << endl;
	cout << "Name: " << this->arr << endl;
}
Mystringj Mystringj::operator+(Mystringj& obj2)
{
	int size1 = strlen(this->arr);
	int size2 = strlen(obj2.arr);
	int sum = 0;
	sum = size1 + size2;
	int i = 0;
	Mystringj temp;
	sum = sum + 2;
	temp.arr = new char[sum];
	for (int i = 0; i < sum; i++)
	{
		temp.arr[i] = '\0';
	}
	for (; i < size1; i++)
	{
		temp.arr[i] = this->arr[i];
	}
	temp.arr[i] = ' ';
	i++;
	int j = 0;
	for (; i < sum; i++, j++)
	{
		temp.arr[i] = obj2.arr[j];
	}
	temp.arr[sum] = '\0';
	cout << temp.arr;
	return temp;
}
Mystringj Mystringj::operator+=(Mystringj& obj2)
{
	int size1 = strlen(this->arr);
	int size2 = strlen(obj2.arr);
	char *temp = new char[size1];
	for (int i = 0; i < size1 + 1; i++)
	{
		temp[i] = '\0';
	}
	for (int i = 0; i < size1 + 1; i++)
	{
		temp[i] = this->arr[i];
	}
	temp[size1] = '\0';
	int sum = 0;
	sum = size1 + size2;
	int i = 0;
	sum = sum + 2;
	this->arr = new char[sum];
	for (int i = 0; i < sum; i++)
	{
		this->arr[i] = '\0';
	}
	for (; i < size1; i++)
	{
		this->arr[i] = temp[i];
	}
	this->arr[i] = ' ';
	i++;
	int j = 0;
	for (; i < sum; i++, j++)
	{
		this->arr[i] = obj2.arr[j];
	}
	this->arr[sum] = '\0';
	cout << endl;
	cout << this->arr<<endl;
	return this->arr;
}
Mystringj::~Mystringj()
{
}
