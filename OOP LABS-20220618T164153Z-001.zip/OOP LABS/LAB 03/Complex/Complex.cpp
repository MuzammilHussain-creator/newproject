#include "rectangle.h"
#include<iostream>
using namespace std;
rectangle::rectangle()
{
	real = 0;
	imaginary = 0;
}
void rectangle::display()
{
	cout << "Number1: " << real << endl;
	cout << "Number2: " << imaginary << endl;
}
istream& operator>>(istream& input, rectangle& obj)
{
	input >> obj.real;
	cout << "Number2: ";
	input>>obj.imaginary;
	return input;
}
ostream& operator<<(ostream& ouput, rectangle& obj)
{
	ouput << "Number1: " << obj.real << endl;
	ouput << "Number2: " << obj.imaginary << endl;
	return ouput;
}
int  rectangle::complax(rectangle& obj)
{

	rectangle temp;
	rectangle real;
	temp.real = this->real*obj.real;
	temp.imaginary = this->imaginary*obj.imaginary;
	real.real = temp.real - temp.imaginary;
	temp.real = this->real*obj.imaginary;
	temp.imaginary = this->imaginary*obj.real;
	real.imaginary = temp.real + temp.imaginary;
	obj.real = real.real;
	obj.imaginary = real.imaginary;
	return 0;
}
rectangle::~rectangle()
{
}
