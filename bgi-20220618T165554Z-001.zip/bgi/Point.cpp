#include "Point.h"
#include "graphics.h"
#include"Shapes.h"
#include<string>
#include<iostream>
using namespace std;
Point::Point(string n, int x, int y) :Shapes(n), x(x), y(y)
{
}
void Point::SetX(int x)
{
	this->x = x;
}
void Point::SetY(int y)
{
	this->y = y;
}
int Point::GetX()
{
	return this->x;
}
int Point::GetY()
{
	return this->y;
}
void Point::Draw()
{
	putpixel(x, y, 3);
}
void Point::Print()
{
	cout << "In Point Class: " << endl;
}
Point::~Point()
{
}
