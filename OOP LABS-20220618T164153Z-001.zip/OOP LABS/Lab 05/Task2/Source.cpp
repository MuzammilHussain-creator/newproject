#include <iostream>
#include "Fraction.h"
using namespace std;

int main()
{
	int n1 = 0, d1 = 0;
	cout << "Enter Numinator: ";
	cin >> n1;
	cout << "Enter Denominator; ";
	cin >> d1;
	Fraction one(n1, d1);
	cout << "Enter Numinator: ";
	cin >> n1;
	cout << "Enter Denominator; ";
	cin >> d1;
	Fraction two(n1, d1);
	Fraction three;
	three = one + two;
	three.display();
	three = one - two;
	three.display();
	three = one * two;
	three.display();
	if (one == two)
	{
		cout << "Equal: " << endl;
	}
	if (one != two)
	{
		cout << "Not Equal: " << endl;
	}
	if (one > two)
	{
		cout << "First Fractio Is Greater : " << endl;
	}
	if (one < two)
	{
		cout << "Second Fractio Is Greater : " << endl;
	}
	return 0;
}