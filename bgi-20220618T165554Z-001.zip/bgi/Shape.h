#pragma once
#include <string>
using namespace std;


class Shape
{
protected:
	string name;
public:
	Shape();
	Shape(string s);
	~Shape();
	virtual void draw() = 0;
	virtual void print();
};

