#pragma once
#include<iostream>
using namespace std;
#include<string>
class Shapes
{
protected:
	string name;
public:
	Shapes();
	Shapes(string name);
	void virtual Draw() = 0;
	virtual void Print();
	~Shapes();
};

